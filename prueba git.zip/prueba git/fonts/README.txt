Hello,

If there is a problem, question, or anything about my fonts, please sent an email to ndrienugrie@gmail.com

This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.

Paypal account for donation : https://www.paypal.me/ndrienugrie

Thanks,

INDONESIA - MOHON DIBACA:
Sebelum memutuskan untuk menggunakan font secara komersial.
Ketidaktahuan bukanlah alasan untuk sebuah pelanggaran hukum.
Dengan meng-install font ini, anda dianggap mengerti dan menyetujui
semua Syarat & Ketentuan penggunaan font dibawah ini:

1. Lisensi font ini adalah "Personal Use".
Yang berarti font ini hanya boleh digunakan untuk keperluan pribadi yang sifatnya tidak komersil,
atau tidak menghasilkan profit atau keuntungan, materiil maupun non-materiil.
Baik itu untuk Perorangan/Individual, Agensi Desain Grafis & Periklanan, Percetakan,
dan Perusahaan/Korporasi.

2. DILARANG KERAS menggandakan, mendistribusikan, dan menggunakan font ini
untuk keperluan komersial. Baik itu untuk Iklan, Promosi Sosial Media , TV, Film, Video, Motion Graphic,
Youtube, atau untuk Logo & Kemasan Produk ( Fisik maupun Digital), atau dalam media apapun
dengan tujuan menghasilkan profit atau keuntungan, materiil maupun non-materiil.

3. Menggandakan, mendistribusikan, dan menggunakan font ini untuk keperluan komersial
apapun jenis & bentuknya, TANPA IZIN atau TANPA MEMBELI LISENSI font terlebih dahulu
dari kami sebagai Pembuat dan/atau Pemegang Hak Cipta font, akan dikenakan biaya
Corporate License , atau sesuai dengan ketentuan yang telah diatur dalam Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta
yang berlaku di Republik Indonesia.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami:
Email: 

ndrienugrie@gmail.com

Website :

https://nugsproject.com/

Nug's Project